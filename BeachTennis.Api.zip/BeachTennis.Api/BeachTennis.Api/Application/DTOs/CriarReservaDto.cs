namespace BeachTennis.Api.Application.DTOs;

public class CriarReservaDto
{
    public int ClienteId { get; set; }
    public int QuadraId { get; set; }
    public DateTime Inicio { get; set; }
    public DateTime Fim { get; set; }
}
