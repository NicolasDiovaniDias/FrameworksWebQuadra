namespace BeachTennis.Api.Application.DTOs;

public class ReservaDetalhadaDto
{
    public int Id { get; set; }
    public string Cliente { get; set; } = "";
    public string Quadra { get; set; } = "";
    public DateTime DataReserva { get; set; }
}
