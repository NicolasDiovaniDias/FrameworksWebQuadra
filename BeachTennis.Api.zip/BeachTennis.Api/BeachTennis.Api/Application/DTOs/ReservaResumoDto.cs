namespace BeachTennis.Api.Application.DTOs;

public class ReservaResumoDto
{
    public int Id { get; set; }
    public int QuadraId { get; set; }
    public DateTime DataReserva { get; set; }
}
