namespace BeachTennis.Api.Application.DTOs;

public record CriarReservaResult(
    int Id,
    DateTime Inicio,
    DateTime Fim);
