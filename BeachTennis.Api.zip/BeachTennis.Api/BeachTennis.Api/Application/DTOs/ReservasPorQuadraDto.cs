namespace BeachTennis.Api.Application.DTOs;

public class ReservasPorQuadraDto
{
    public string Quadra { get; set; } = "";
    public int Quantidade { get; set; }
}
