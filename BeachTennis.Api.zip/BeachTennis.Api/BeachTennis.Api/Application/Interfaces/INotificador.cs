namespace BeachTennis.Api.Application.Interfaces;

public interface INotificador
{
    void Enviar(string mensagem);
}
