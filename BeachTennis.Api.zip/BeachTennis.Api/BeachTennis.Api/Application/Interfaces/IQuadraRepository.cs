using BeachTennis.Api.Domain.Entities;

namespace BeachTennis.Api.Application.Interfaces;

public interface IQuadraRepository
{
    Task<List<Quadra>> ListarAtivasAsync();

    Task<Quadra?> BuscarPorIdAsync(int id);
}
