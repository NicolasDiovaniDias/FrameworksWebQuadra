using BeachTennis.Api.Application.DTOs;
using BeachTennis.Api.Application.Interfaces;
using BeachTennis.Api.Domain.Entities;
using BeachTennis.Api.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace BeachTennis.Api.Application.Services;

public class ReservaService
{
    private readonly AppDbContext _db;
    private readonly INotificador _notificador;

    public ReservaService(AppDbContext db, INotificador notificador)
    {
        _db = db;
        _notificador = notificador;
    }

    // Caso de uso: Criar Reserva
    public async Task<CriarReservaResult> CriarAsync(CriarReservaDto dto)
    {
        var cliente = await _db.Clientes.FindAsync(dto.ClienteId);

        if (cliente == null)
            throw new InvalidOperationException("Cliente não encontrado.");

        var quadra = await _db.Quadras.FindAsync(dto.QuadraId);

        if (quadra == null)
            throw new InvalidOperationException("Quadra não encontrada.");

        if (!quadra.Ativa)
            throw new InvalidOperationException("Quadra inativa.");

        // A regra "Fim > Inicio" pertence à entidade Reserva.
        var reserva = new Reserva(
            dto.ClienteId,
            dto.QuadraId,
            dto.Inicio,
            dto.Fim);

        // Regra contextual: uma quadra não pode ter 2 reservas no mesmo horário.
        bool conflito = await _db.Reservas
            .AnyAsync(r => r.QuadraId == dto.QuadraId &&
                           r.Inicio < dto.Fim &&
                           r.Fim > dto.Inicio);

        if (conflito)
            throw new InvalidOperationException("Quadra indisponível nesse horário.");

        _db.Reservas.Add(reserva);
        await _db.SaveChangesAsync();

        _notificador.Enviar("Sua reserva foi confirmada!");

        return new CriarReservaResult(
            reserva.Id,
            reserva.Inicio,
            reserva.Fim);
    }

    // Caso de uso: Consultar Reservas (paginado)
    public async Task<List<ReservaDetalhadaDto>> ListarAsync(int pagina, int tamanhoPagina)
    {
        return await _db.Reservas
            .OrderBy(r => r.Inicio)
            .ThenBy(r => r.Id)
            .Skip((pagina - 1) * tamanhoPagina)
            .Take(tamanhoPagina)
            .Select(r => new ReservaDetalhadaDto
            {
                Id = r.Id,
                Cliente = r.Cliente.Nome,
                Quadra = r.Quadra.Nome,
                DataReserva = r.Inicio
            })
            .ToListAsync();
    }

    public async Task<List<ReservaResumoDto>> ListarPorClienteAsync(int clienteId)
    {
        return await _db.Reservas
            .Where(r => r.ClienteId == clienteId)
            .OrderBy(r => r.Inicio)
            .Select(r => new ReservaResumoDto
            {
                Id = r.Id,
                QuadraId = r.QuadraId,
                DataReserva = r.Inicio
            })
            .ToListAsync();
    }

    // Próximas cinco reservas da quadra
    public async Task<List<ReservaResumoDto>> ListarProximasDaQuadraAsync(int quadraId)
    {
        var agora = DateTime.Now;

        return await _db.Reservas
            .Where(r => r.QuadraId == quadraId &&
                        r.Inicio > agora)
            .OrderBy(r => r.Inicio)
            .ThenBy(r => r.Id)
            .Select(r => new ReservaResumoDto
            {
                Id = r.Id,
                QuadraId = r.QuadraId,
                DataReserva = r.Inicio
            })
            .Take(5)
            .ToListAsync();
    }

    // Ranking das quadras com maior número de reservas
    public async Task<List<ReservasPorQuadraDto>> RankingQuadrasAsync()
    {
        return await _db.Reservas
            .GroupBy(r => new
            {
                r.QuadraId,
                r.Quadra.Nome
            })
            .Select(g => new ReservasPorQuadraDto
            {
                Quadra = g.Key.Nome,
                Quantidade = g.Count()
            })
            .OrderByDescending(r => r.Quantidade)
            .ToListAsync();
    }
}
