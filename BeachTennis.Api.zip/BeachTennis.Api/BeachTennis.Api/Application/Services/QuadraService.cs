using BeachTennis.Api.Application.Interfaces;
using BeachTennis.Api.Domain.Entities;

namespace BeachTennis.Api.Application.Services;

public class QuadraService
{
    private readonly IQuadraRepository _repository;

    public QuadraService(IQuadraRepository repository)
    {
        _repository = repository;
    }

    public async Task<List<Quadra>> ListarAtivasAsync()
    {
        return await _repository.ListarAtivasAsync();
    }
}
