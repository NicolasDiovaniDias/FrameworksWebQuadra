using BeachTennis.Api.Application.DTOs;
using BeachTennis.Api.Application.Interfaces;
using BeachTennis.Api.Application.Services;
using BeachTennis.Api.Domain.Entities;
using BeachTennis.Api.Infrastructure.Persistence;
using BeachTennis.Api.Infrastructure.Repositories;
using BeachTennis.Api.Infrastructure.Services;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddDbContext<AppDbContext>();
builder.Services.AddScoped<IQuadraRepository, QuadraRepository>();
builder.Services.AddScoped<QuadraService>();
builder.Services.AddScoped<INotificador, EmailService>();
builder.Services.AddScoped<ReservaService>();

var app = builder.Build();

// Configure the HTTP request pipeline.

app.UseHttpsRedirection();

// Quadras

app.MapPost("/api/quadras", async (Quadra quadra, AppDbContext db) =>
{
    db.Quadras.Add(quadra);
    await db.SaveChangesAsync();

    return Results.Created($"/api/quadras/{quadra.Id}", quadra);
});

app.MapGet("/api/quadras", async (AppDbContext db) =>
{
    return await db.Quadras.AsNoTracking().ToListAsync();
});

app.MapGet("/api/quadras/ativas", async (QuadraService service) =>
{
    var quadras = await service.ListarAtivasAsync();

    return Results.Ok(quadras);
});

app.MapGet("/api/quadras/{quadraId}/reservas/proximas", async (int quadraId, ReservaService service) =>
{
    var reservas = await service.ListarProximasDaQuadraAsync(quadraId);

    return Results.Ok(reservas);
});

// Clientes

app.MapPost("/api/clientes", async (Cliente cliente, AppDbContext db) =>
{
    db.Clientes.Add(cliente);
    await db.SaveChangesAsync();

    return Results.Created($"/api/clientes/{cliente.Id}", cliente);
});

app.MapGet("/api/clientes", async (AppDbContext db) =>
{
    return await db.Clientes.AsNoTracking().ToListAsync();
});

app.MapGet("/api/clientes/{clienteId}/reservas", async (int clienteId, ReservaService service) =>
{
    var reservas = await service.ListarPorClienteAsync(clienteId);

    return Results.Ok(reservas);
});

// Reservas

app.MapPost("/api/reservas", async (CriarReservaDto dto, ReservaService service) =>
{
    try
    {
        var resultado = await service.CriarAsync(dto);

        return Results.Ok(resultado);
    }
    catch (ArgumentException ex)
    {
        return Results.BadRequest(ex.Message);
    }
    catch (InvalidOperationException ex)
    {
        return Results.BadRequest(ex.Message);
    }
});

app.MapGet("/api/reservas", async (ReservaService service, int pagina = 1, int tamanhoPagina = 10) =>
{
    var reservas = await service.ListarAsync(pagina, tamanhoPagina);

    return Results.Ok(reservas);
});

app.MapGet("/api/reservas/ranking-quadras", async (ReservaService service) =>
{
    var resultado = await service.RankingQuadrasAsync();

    return Results.Ok(resultado);
});

app.Run();
