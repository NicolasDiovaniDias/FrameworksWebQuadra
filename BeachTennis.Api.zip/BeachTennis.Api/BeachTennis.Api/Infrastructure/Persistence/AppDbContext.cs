using BeachTennis.Api.Domain.Entities;
using BeachTennis.Api.Infrastructure.Persistence.Configurations;
using Microsoft.EntityFrameworkCore;

namespace BeachTennis.Api.Infrastructure.Persistence;

public class AppDbContext : DbContext
{
    public DbSet<Quadra> Quadras { get; set; }
    public DbSet<Cliente> Clientes { get; set; }
    public DbSet<Reserva> Reservas { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        optionsBuilder.UseSqlite("Data Source=beachtennis.db");
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        modelBuilder.ApplyConfiguration(new QuadraConfiguration());

        modelBuilder.Entity<Reserva>()
            .HasIndex(r => r.ClienteId);

        modelBuilder.Entity<Reserva>()
            .HasIndex(r => new
            {
                r.QuadraId,
                r.Inicio
            });
    }
}
