using BeachTennis.Api.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BeachTennis.Api.Infrastructure.Persistence.Configurations;

public class QuadraConfiguration
    : IEntityTypeConfiguration<Quadra>
{
    public void Configure(
        EntityTypeBuilder<Quadra> builder)
    {
        builder.ToTable("Quadras");

        builder.HasKey(q => q.Id);

        builder.Property(q => q.Nome)
            .IsRequired()
            .HasMaxLength(100);

        builder.Property(q => q.ValorHora)
            .HasPrecision(10, 2);
    }
}
