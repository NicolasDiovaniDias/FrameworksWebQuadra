using BeachTennis.Api.Application.Interfaces;

namespace BeachTennis.Api.Infrastructure.Services;

public class EmailService : INotificador
{
    public void Enviar(string mensagem)
    {
        Console.WriteLine($"Email enviado: {mensagem}");
    }
}
