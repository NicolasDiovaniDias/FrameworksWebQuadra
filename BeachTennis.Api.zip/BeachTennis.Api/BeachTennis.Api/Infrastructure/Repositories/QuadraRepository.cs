using BeachTennis.Api.Application.Interfaces;
using BeachTennis.Api.Domain.Entities;
using BeachTennis.Api.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace BeachTennis.Api.Infrastructure.Repositories;

public class QuadraRepository : IQuadraRepository
{
    private readonly AppDbContext _db;

    public QuadraRepository(AppDbContext db)
    {
        _db = db;
    }

    public async Task<List<Quadra>> ListarAtivasAsync()
    {
        return await _db.Quadras
            .AsNoTracking()
            .Where(q => q.Ativa)
            .ToListAsync();
    }

    public async Task<Quadra?> BuscarPorIdAsync(int id)
    {
        return await _db.Quadras.FindAsync(id);
    }
}
